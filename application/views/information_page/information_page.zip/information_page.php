<style>
    .note {
        height: 60vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .noteBlack{
        font-weight: 700;
        font-size: 3rem;
        font-family: gilroybold;
    }
    .note-p{
        font-weight: 700;
        font-family: 'gilroymedium';
        font-size: 18px;
    }
</style>
<div class="container">

    <div class="note d-flex justify-content-center align-items-center flex-column text-center">
    <!-- <form action="checkout.php" method="POST"> -->
      <!-- <a href="<?php echo g('base_url'); ?>information_page/checkout">Checkout</a> -->
    <!-- </form> -->
        <!-- <span class="noteBlack">Note</span> -->
        <span class="note-p">You will receive an approval or denial email within 48-72. You are responsible for the background check regardless of approval/denial. In the event you are denied, you will be credited back the subscription fee.</span>
    </div>
</div>